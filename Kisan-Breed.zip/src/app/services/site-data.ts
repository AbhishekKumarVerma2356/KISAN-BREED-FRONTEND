import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SiteData {
  private http = inject(HttpClient);

  getSite(): Observable<any> {
    return this.http.get('assets/data/site.json');
  }

  getProducts(): Observable<any> {
    return this.http.get('assets/data/products.json');
  }

  getTestimonials(): Observable<any> {
    return this.http.get('assets/data/testimonials.json');
  }

  getFaqs(): Observable<any> {
    return this.http.get('assets/data/faqs.json');
  }

  getGallery(): Observable<any> {
    return this.http.get('assets/data/gallery.json');
  }

  getCertificates(): Observable<any> {
    return this.http.get('assets/data/certificates.json');
  }

  getAll(): Observable<any> {
    return forkJoin({
      site: this.getSite(),
      products: this.getProducts(),
      testimonials: this.getTestimonials(),
      faqs: this.getFaqs(),
      gallery: this.getGallery(),
      certificates: this.getCertificates(),
    });
  }
}
