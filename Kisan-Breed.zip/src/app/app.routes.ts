import { Routes } from '@angular/router';
import { HomePage } from './pages/home-page/home-page';
import { AboutPage } from './pages/about-page/about-page';
import { ProductDetailPage } from './pages/product-detail-page/product-detail-page';
import { ProductsPage } from './pages/products-page/products-page';
import { ContactPage } from './pages/contact-page/contact-page';

export const routes: Routes = [
  { path: '', component: HomePage },
  { path: 'about', component: AboutPage },
  { path: 'products', component: ProductsPage },
  { path: 'products/:slug', component: ProductDetailPage },
  { path: 'contact', component: ContactPage },
  { path: '**', redirectTo: '' },
];
