import { Component, inject, OnInit } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { SiteData } from '../../services/site-data';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-detail-page',
  imports: [CommonModule, RouterLink],
  templateUrl: './product-detail-page.html',
  styleUrl: './product-detail-page.css',
})
export class ProductDetailPage implements OnInit {
  private route = inject(ActivatedRoute);
  private service = inject(SiteData);

  product: any = null;
  isLoading = true;

  ngOnInit(): void {
    const slug = this.route.snapshot.paramMap.get('slug');

    this.service.getProducts().subscribe({
      next: (data: any) => {
        this.product = (data.products || []).find((item: any) => item.slug === slug) || null;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Product detail load error:', error);
        this.isLoading = false;
      },
    });
  }
}
