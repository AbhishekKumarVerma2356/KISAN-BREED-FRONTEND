import { Component, inject } from '@angular/core';
import { SiteData } from '../../services/site-data';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-about-page',
  imports: [CommonModule],
  templateUrl: './about-page.html',
  styleUrl: './about-page.css',
})
export class AboutPage {
  private service = inject(SiteData);
  site: any = null;

  ngOnInit(): void {
    this.service.getSite().subscribe((siteData: any) => {
      this.site = siteData;
    });
  }
}
