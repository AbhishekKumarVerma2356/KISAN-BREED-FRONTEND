import { Component, inject } from '@angular/core';
import { SiteData } from '../../services/site-data';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-products-page',
  imports: [CommonModule, RouterLink],
  templateUrl: './products-page.html',
  styleUrl: './products-page.css',
})
export class ProductsPage {
  private service = inject(SiteData);

  site: any = null;
  products: any[] = [];
  isLoading = true;

  ngOnInit(): void {
    this.service.getSite().subscribe((siteData: any) => {
      this.site = siteData;
    });

    this.service.getProducts().subscribe({
      next: (data: any) => {
        this.products = data.products || [];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Products load error:', error);
        this.isLoading = false;
      },
    });
  }
}
