import { Component, inject } from '@angular/core';
import { SiteData } from '../../services/site-data';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home-page',
  imports: [CommonModule, RouterLink],
  templateUrl: './home-page.html',
  styleUrl: './home-page.css',
})
export class HomePage {
  private service = inject(SiteData);

  site: any = null;
  products: any[] = [];
  faqs: any[] = [];
  gallery: any[] = [];
  certificates: any[] = [];
  isLoading = true;

  ngOnInit(): void {
    this.service.getAll().subscribe({
      next: (data) => {
        this.site = data.site;
        this.products = data.products.products || [];
        this.faqs = data.faqs.faqs || [];
        this.gallery = data.gallery.gallery || [];
        this.certificates = data.certificates.certificates || [];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Home page data load error:', error);
        this.isLoading = false;
      },
    });
  }
}
