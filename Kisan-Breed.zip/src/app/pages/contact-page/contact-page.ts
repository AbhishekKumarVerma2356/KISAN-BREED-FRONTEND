import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact-page',
  imports: [CommonModule, FormsModule],
  templateUrl: './contact-page.html',
  styleUrl: './contact-page.css',
})
export class ContactPage {
  formData = {
    name: '',
    phone: '',
    email: '',
    message: '',
  };

  onSubmit(): void {
    console.log('Contact Form Data:', this.formData);
    alert('Form submitted successfully!');
  }
}
